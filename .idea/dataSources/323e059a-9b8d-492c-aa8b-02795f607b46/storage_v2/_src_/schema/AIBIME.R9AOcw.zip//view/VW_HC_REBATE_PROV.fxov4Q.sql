create view VW_HC_REBATE_PROV as
WITH VW_TEMP AS (


    SELECT
          TRUNC(REPORT_DATE,'MONTH') AS PERIOD
         ,A.BU
         ,CASE WHEN  A.MASTER_BUYER IN ('Legero','Pelikan/Herlitz','E. Breuninger','Edeka') THEN A.MASTER_BUYER
               WHEN  A.ORIGINAL_COMPANY_NAME IN ('digi-tech GmbH','BSN medical GmbH','Essity BSN medical GmbH','MeLiTec GmbH') THEN A.ORIGINAL_COMPANY_NAME
               WHEN  A.BUYER IN ('Consumer Lab Denmark (ForbrugerLaboratoriet)') THEN A.BUYER

          END
          AS CLIENT
         ,SUM(A.ORIG_AMT) AS TURNOVER --For now only EUR so it's ok, but need to plan to convert all to EUROS
         ,SUM(CASE WHEN A.TYPE = 'Rebate' THEN 0 ELSE A.ORIG_AMT END) AS TURNOVER_EXCL_REBATE

    FROM AIBIME.ACQUISITION_CURR_YEAR A

    WHERE (A.MASTER_BUYER IN ('Legero','Pelikan/Herlitz','E. Breuninger','Edeka')
        OR A.ORIGINAL_COMPANY_NAME IN ('digi-tech GmbH','BSN medical GmbH','Essity BSN medical GmbH','MeLiTec GmbH')
        OR A.BUYER IN ('Consumer Lab Denmark (ForbrugerLaboratoriet)')
        )

    AND NOT (UPPER(A.BUYER) LIKE 'EDEKA%' AND NOT ORDER_NO LIKE '%CR%' AND NOT ORIGINAL_COMPANY_NAME = 'YORK PL sp. z o.o. sp.k.')
    AND NOT (A.ORIGINAL_COMPANY_NAME IN ('EDEKA Nonfood-CM GmbH','BUDNI Handels- und Service GmbH & Co. KG'))
    AND   A.REPORT_DATE >= TO_DATE ('2021-01-01','yyyy-mm-dd')
    AND NOT NVL(INTERCO,' ') = 'Y'
    AND A.BU IN ('HC PI','HC Cert')


    GROUP BY
            TRUNC(REPORT_DATE,'MONTH')
           ,A.BU
           ,CASE WHEN  A.MASTER_BUYER IN ('Legero','Pelikan/Herlitz','E. Breuninger','Edeka') THEN A.MASTER_BUYER
               WHEN  A.ORIGINAL_COMPANY_NAME IN ('digi-tech GmbH','BSN medical GmbH','Essity BSN medical GmbH','MeLiTec GmbH') THEN A.ORIGINAL_COMPANY_NAME
               WHEN  A.BUYER IN ('Consumer Lab Denmark (ForbrugerLaboratoriet)') THEN A.BUYER

            END

)


 ,VW_CALENDAR AS (

    SELECT TO_DATE('2021'||TO_CHAR(LEVEL,'00')||'01','yyyymmdd') AS PERIOD,LEVEL AS MONTH_NB

    FROM DUAL A
    CONNECT BY LEVEL<=12


)

 ,VW_BASE AS (

     SELECT B.PERIOD,B.MONTH_NB,A.CLIENT

         FROM VW_CALENDAR B
         CROSS JOIN (SELECT DISTINCT CLIENT FROM VW_TEMP) A

)


 ,VW_CUMUL_TO AS (


 SELECT

      C.PERIOD
    , C.CLIENT
    , C.MONTH_NB
    , NVL(SUM(A.TURNOVER_EXCL_REBATE) OVER (PARTITION BY A.CLIENT ORDER BY A.PERIOD ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0) AS CUMUL_YTD_TO_CLIENT_LVL
    FROM VW_BASE C
         LEFT JOIN (SELECT PERIOD,CLIENT,SUM(TURNOVER_EXCL_REBATE) AS TURNOVER_EXCL_REBATE
          FROM VW_TEMP GROUP BY PERIOD,CLIENT) A ON A.PERIOD = C.PERIOD AND A.CLIENT = C.CLIENT

)


 ,VW_PROJECTED_TO AS (

     SELECT
           A.PERIOD
          ,A.CLIENT
          ,B.BU
          ,A.CUMUL_YTD_TO_CLIENT_LVL
          ,ROUND(A.CUMUL_YTD_TO_CLIENT_LVL/A.MONTH_NB*12,0)*1.15  AS CLIENT_FY_PROJECTED_TO --better estimation to be calculated
          ,ROUND(MAX(A.CUMUL_YTD_TO_CLIENT_LVL/A.MONTH_NB*12*1.15) OVER (PARTITION BY A.CLIENT ORDER BY A.PERIOD ROWS BETWEEN UNBOUNDED
                                                                                                   PRECEDING AND CURRENT ROW),0)
              AS HIGHEST_CLIENT_FY_PROJECTED_TO

      FROM VW_CUMUL_TO A
      LEFT JOIN (SELECT DISTINCT CLIENT,BU FROM VW_TEMP) B ON A.CLIENT = B.CLIENT

)

   ,VW_REBATE_RATE AS (


SELECT
      B.PERIOD
    , B.CLIENT
    , B.BU
    , A.TURNOVER
    , A.TURNOVER_EXCL_REBATE
    , SUM(A.TURNOVER_EXCL_REBATE) OVER (PARTITION BY B.CLIENT,B.BU ORDER BY B.PERIOD ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS CUMUL_YTD_TO
    , B.CUMUL_YTD_TO_CLIENT_LVL
    , B.CLIENT_FY_PROJECTED_TO
    , B.HIGHEST_CLIENT_FY_PROJECTED_TO
--
--     , CASE WHEN B.CLIENT = 'Pelikan/Herlitz' THEN
--            CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 200000 THEN 200000
--                 WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 160000 THEN 160000
--
--                 ELSE 0
--            END
--         ELSE 0
--         END AS REBATE_BASE_AMT -- name to be clarified
--
--     , CASE WHEN B.CLIENT = 'Pelikan/Herlitz' THEN 3/100
--         END AS REBATE_BASE_RATE -- name to be clarified

    , ROUND(

        CASE WHEN B.CLIENT = 'E. Breuninger' THEN

             LEAST(1 + B.CUMUL_YTD_TO_CLIENT_LVL / 600000,2) / 100

             WHEN B.CLIENT = 'Edeka' THEN 15/100/0.85 --0.85 = take raw amount instead of net amount.
             --15/100 * SUM(A.TURNOVER) OVER (PARTITION BY A.CLIENT ORDER BY A.PERIOD ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) / 0.85

             WHEN B.CLIENT  =  'digi-tech GmbH' THEN

                  CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 200000 THEN 17.5/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 150000 THEN 15/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 100000 THEN 12.5/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 50000  THEN 5/100

                       ELSE 0
                  END

             WHEN B.CLIENT  =  'Legero' THEN

                  CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 250000 THEN 10/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 200000 THEN 5/100
                       ELSE 0
                  END

             WHEN B.CLIENT  =  'BSN medical GmbH' THEN

                  CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 250000 THEN 10/100
                       ELSE 0
                  END

             WHEN B.CLIENT  =  'Consumer Lab Denmark (ForbrugerLaboratoriet)' THEN

                  CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 50000 THEN 6/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 25000 THEN 4/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 15000 THEN 2/100
                       ELSE 0
                  END

             WHEN B.CLIENT  =  'Pelikan/Herlitz' THEN --TBC

                  CASE --WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 200000  THEN 4/100
                       --WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 160000  THEN 3.5/100
                       WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 140000  THEN 3/100
                       ELSE 0
                  END

             WHEN B.CLIENT  =  'Essity BSN medical GmbH' THEN

                  CASE WHEN B.HIGHEST_CLIENT_FY_PROJECTED_TO > 150000 THEN 10/100
                       ELSE 0
                  END

             WHEN B.CLIENT  =  'MeLiTec GmbH' THEN 7.5/100

             WHEN B.CLIENT  =  'Spar Österreich' THEN 2/100


             END

           , 6)  AS REBATE_RATE

FROM  VW_PROJECTED_TO  B
 LEFT JOIN VW_TEMP A ON A.PERIOD = B.PERIOD AND A.CLIENT = B.CLIENT AND A.BU = B.BU


)

SELECT A.PERIOD
     , A.CLIENT
     , A.BU
     , NVL(A.TURNOVER,0) AS TURNOVER
     , NVL(A.TURNOVER_EXCL_REBATE,0) AS TURNOVER_EXCL_REBATE
     , NVL(A.CUMUL_YTD_TO,0) AS CUMUL_YTD_TO
     , NVL(A.CUMUL_YTD_TO_CLIENT_LVL,0) AS CUMUL_YTD_TO_CLIENT_LVL
     , NVL(A.CLIENT_FY_PROJECTED_TO,0) AS CLIENT_FY_PROJECTED_TO
     , NVL(A.HIGHEST_CLIENT_FY_PROJECTED_TO,0) AS HIGHEST_CLIENT_FY_PROJECTED_TO

     , NVL(A.REBATE_RATE,0) AS REBATE_RATE
     , NVL((A.CUMUL_YTD_TO) * A.REBATE_RATE,0) AS CUMUL_YTD_REBATE
     , NVL(LAG(A.CUMUL_YTD_TO * A.REBATE_RATE,1) OVER (PARTITION BY A.CLIENT,A.BU  ORDER BY PERIOD)  * -1,0) AS REBATE_PREV_MONTH_REVERSAL
     , NVL(A.CUMUL_YTD_TO * A.REBATE_RATE
               + NVL(LAG(A.CUMUL_YTD_TO * A.REBATE_RATE,1) OVER (PARTITION BY A.CLIENT,A.BU ORDER BY PERIOD)  * -1,0),0) AS ACTUAL_MONTHLY_REBATE


FROM VW_REBATE_RATE A

WHERE  PERIOD < TRUNC(SYSDATE,'MONTH')

ORDER BY A.CLIENT,A.PERIOD,A.BU
/

