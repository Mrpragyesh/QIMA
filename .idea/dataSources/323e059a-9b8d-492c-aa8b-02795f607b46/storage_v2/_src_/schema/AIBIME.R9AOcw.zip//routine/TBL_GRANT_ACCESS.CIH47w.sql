create PROCEDURE        TBL_GRANT_ACCESS(
  var_access_name VARCHAR2
, var_staff_name VARCHAR2
, var_decryption_key VARCHAR2
, var_force_private_pw_send INT DEFAULT 0
, var_send_pw_email_to_user INT DEFAULT 1

) AS

    i INT;
    var_tbl_account_pw VARCHAR2(32);
    var_private_password VARCHAR2(8) := DBMS_RANDOM.STRING('A', 8);
    var_existing_private_password VARCHAR2(32);

BEGIN
DBMS_OUTPUT.ENABLE (20000);

--DELETE FROM AIBIME.JOB_EMAILS WHERE JOB_SCHEDULE_ID  = 'SEND_NEW_TBL_CREDENTIALS'; COMMIT;

SELECT
      UTL_RAW.CAST_TO_VARCHAR2(
   DBMS_CRYPTO.DECRYPT(
      PASSWORD
    , 4353
    , UTL_RAW.CAST_TO_RAW (var_decryption_key))
    ) INTO var_tbl_account_pw

FROM AIBIME.TBL_ACCESS
WHERE ACCESS_NAME = var_access_name
;

SELECT MAX(PRIVATE_PW) INTO var_existing_private_password
FROM AIBIME.TBL_ACCESS_LIST
WHERE USER_NAME = var_staff_name
;


INSERT INTO AIBIME.TBL_ACCESS_LIST (ACCESS_NAME, USER_ID, USER_NAME, PRIVATE_PW, COMMENTS, CREATE_TIME, UPDATE_TIME, CREATE_BY, UPDATE_BY)

SELECT var_access_name
     ,A.STAFF_ID
     ,A.STAFF_NAME
     ,NVL(var_existing_private_password,var_private_password)
     ,NULL
     ,SYSTIMESTAMP
     ,SYSTIMESTAMP
     ,USER
     ,USER

       FROM AIBIME.STAFF_PROFILE A
       JOIN AIBIME.TBL_ACCESS    B ON var_access_name = B.ACCESS_NAME

WHERE A.STAFF_NAME = var_staff_name
  AND A.STATUS = 'Active'
  AND A.STAFF_NAME_NB = 1
  AND A.STAFF_NAME NOT IN (SELECT STAFF_NAME FROM AIBIME.TBL_ACCESS_LIST X  WHERE X.USER_NAME = var_staff_name AND X.ACCESS_NAME = var_access_name) --we do not insert a new record if it already exists

;

i := SQL%rowcount;

INSERT INTO AIBIME.JOB_EMAILS A (

 JOB_SCHEDULE_ID
,JOB_NAME
,MAIL_FROM
,MAIL_TO
,MAIL_CC
,MAIL_BCC
,SUBJECT
,SUBJECT_DATE
,BODY_START
,BODY_END
,MIN_JOB_REQUIRED
,CREATE_TIME
,UPDATE_TIME
,CREATED_BY
,UPDATED_BY
,FORCE_SENDING

)

SELECT
 'SEND_NEW_TBL_CREDENTIALS'
,CASE WHEN B.REQUIRES_PRIVATE_PW = 1 OR var_force_private_pw_send=1 THEN 'tbl_credentials_private_pw_png,' END || 'TBL_DELETE_CRED_MAIL_JOB,' || 'Refresh_User_Access'
,'dashboards@qima.com'
,A.MAIN_EMAIL
,NULL
,'antoine.chapelet@qima.com'||
 CASE WHEN USER = 'PMISHRA' THEN ';pragyesh.mishra@qima.com' END
,'QIMA Dashboards - '||var_access_name||' Access Credentials for '||A.STAFF_NAME
,NULL
,'<span style="color: #ff0000;"><strong>!!! IMPORTANT: The accesses shared in this e-mail are personal and must not be shared with anyone else.</strong></span><br /><span style="color: #ff0000;"><strong>If someone asks you the credentials, please instruct him/her to reach <a href="mailto:antoine.chapelet@qima.com">antoine.chapelet@qima.com</a> directly.</strong></span><br><br>
Hi '||var_staff_name||',<br><br>
Here are the details to log to our dashboard platform:<br><br>
URL: <a href="https://dashboards.qima.com/">https://dashboards.qima.com/</a><br />Login: <span style="text-decoration: underline;"><strong>'||var_access_name||'</strong></span><br />Portal Password: <span style="text-decoration: underline;"><strong>'||var_tbl_account_pw ||'</strong></span><br><br>'
||CASE WHEN B.REQUIRES_PRIVATE_PW = 1 OR var_force_private_pw_send=1 THEN

'By default, all dashboards will be empty & content will be displayed after you input & validate your 2nd private password: <span style="text-decoration: underline;"><strong> '|| NVL(var_existing_private_password,var_private_password) ||'</strong></span> <i> (you can request to modify this password if needed, as it is specific to you only)</i><br><br>'

    END

,'<br>Let us know if you have any questions.<br><br><br>'
,0
,SYSTIMESTAMP
,SYSTIMESTAMP
,USER
,USER
,1

FROM AIBIME.STAFF_PROFILE A
JOIN AIBIME.TBL_ACCESS    B ON var_access_name = B.ACCESS_NAME


WHERE A.STAFF_NAME = var_staff_name

 AND A.STATUS = 'Active'
 AND A.STAFF_NAME_NB = 1
 AND var_send_pw_email_to_user = 1

;


COMMIT;

DBMS_OUTPUT.PUT_LINE(i || ' row(s) added');
DBMS_OUTPUT.PUT_LINE('Password for '||var_staff_name||' is '||var_private_password);

END;
/

